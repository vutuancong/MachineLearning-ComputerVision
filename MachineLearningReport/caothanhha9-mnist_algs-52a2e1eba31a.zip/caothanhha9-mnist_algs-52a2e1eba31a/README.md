- cnn_basic requirements:
    + tensorflow 0.7.1
    + numpy